#!/usr/bin/env bash
echo "[ENTRYPOINT] - Starting kamailio."
cat /etc/kamailio/kamailio.cfg ||:
/usr/sbin/kamailio -DD -E -m 4096 -M 512 -f /etc/kamailio/kamailio.cfg
