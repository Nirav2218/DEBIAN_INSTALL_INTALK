-- Kamailio - equivalent of routing blocks in Lua
--
-- KSR - the new dynamic object exporting Kamailio functions (kemi)
-- sr - the old static object exporting Kamailio functions
--

package.path = package.path .. ";/etc/kamailio/?.lua" ..
        ";/etc/kamailio/utils/?.lua" .. ";/etc/kamailio/core/?.lua"
-- ----------------- Declaration of Flags ------------------------------------
--	FLT_ - per transaction (message) flags
--	FLB_ - per branch flags
FLT_NATS = 1 -- the UAC is behind a NAT
-- There can be multiple Bs (forking), thus the NAT information must
-- be stored in a branch-flag.
FLB_NATB = 2 -- the UAS is behind a NAT
FLT_DIALOG = 4

-- ----------------- Import Lua Modules ------------------------------------
local included_modules = {
    "globals",
    "headers",
    "logger",
    "core",
    "nathandling",
    "security",
    "message"
}
for _, module in pairs(included_modules) do
    package.loaded[module] = nil
end
local config = require "globals" -- Importing globals variables
local headers = require "headers" -- Importing the headers module
local logger = require "logger" -- Importing the logger module
local core = require "core" -- Importing the kamailio core functionality
local nathandling = require "nathandling" -- Importing the kamailio nathandling functionality
local security = require "security"
local message = require "message"

-- -------------------------  Request Routing Logic --------------------------

--[[--------------------------------------------------------------------------
   Name: ksr_request_route()
   Desc: -- equivalent of request_route{}
------------------------------------------------------------------------------]]

function ksr_request_route()
    local request_method = headers.get("$rm") or "";
    local user_agent = headers.get("$ua") or "";
    -- per request initial checks
    ksr_route_reqinit(user_agent);
    -- OPTIONS processing
    ksr_route_options_process(request_method);
    -- NAT detection
    ksr_route_natdetect();
    -- CANCEL processing
    ksr_route_cancel_process(request_method);

     -- handle requests within SIP dialogs
    ksr_route_withindlg(request_method);
    -- handle retransmissions
    ksr_route_retrans_process();

    authorize_request()
 
    ksr_route_registrar();

    -- handle request without to tag
    -- ksr_route_request_process(request_method);
   ksr_route_location() 
    return 1;
end


-- IP authorization and user uthentication
function authorize_request()

   if KSR.pv.get("$rm") == "INVITE" then
 	return 1;
   end 
  
  -- if caller is not local subscriber, then check if it calls
  -- a local destination, otherwise deny, not an open relay here
  if (not message.is_request_from_local_from_domain())
      and (not message.is_request_to_local_request_domain()) then
  	core.sl_send_reply(403, "Forbidden");
        core.exit()
  end
  
  if message.is_register() or message.is_request_from_local_from_domain() then
    -- authenticate requests
    if security.is_not_authenticated() then
      security.send_auth_challenge()
      core.exit()
    end
    -- user authenticated - remove auth header
    if not message.is_register()  then
      security.remove_credentials()
    end
  end

  return 1;
end

-- User location service
function ksr_route_location()
	if KSR.pv.get("$rm")~="INVITE" then return 1; end
	KSR.info("===== ksr_route_location \n");
	local rc = KSR.registrar.lookup("location",4);
	if rc<0 then
		KSR.tm.t_newtran();
		if rc==-1 or rc==-3 then
			KSR.sl.send_reply("404", "Not Found");
			KSR.x.exit();
		elseif rc==-2 then
			KSR.sl.send_reply("405", "Method Not Allowed");
			KSR.x.exit();
		end
	end

	-- when routing via usrloc, log the missed calls also
	if KSR.pv.get("$rm")=="INVITE" then
		KSR.setbflag(FLB_NATB);
                -- do SIP NAT pinging
                KSR.setbflag(FLB_NATSIPPING);
		headers.add_record_route();
	end
	KSR.nathelper.handle_ruri_alias()
	ksr_route_relay("INVITE");
	KSR.x.exit();
end

function ksr_route_register_callback(reg_status)
    local to_user = headers.get("$aU")
    local to_domain = headers.get("$td")
    local payload = "{\"sipUser\":" .. "\"" .. "sip:" .. to_user .. "@" .. to_domain .. "\"," .. "\"registerStatus\":" .. "\"" .. reg_status  .. "\"" .. "}"
--    KSR.rabbitmq.publish("kamailio", "register_callback", "application/json", payload)
    KSR.ndb_redis.redis_cmd("srv1","PUBLISH kamailio_events ".. payload,"r")
end

--[[--------------------------------------------------------------------------
   Name: ksr_route_reqinit()
   Desc: -- Per SIP request initial checks
------------------------------------------------------------------------------]]

function ksr_route_reqinit(user_agent)
    if not core.check_maxfwd(max_forward) then
    	logger.log("err", "too many hops sending 483");
        core.sl_send_reply(483, "Too Many Hops");
        core.exit()
    elseif not core.sanity() then
    	logger.log("err", "received invalid SIP packet");
        core.exit()
    end
    logger.log("dbg", "initial request check is passed");
    return 1;
end

-- Handle SIP egistrations
function ksr_route_registrar()
	if KSR.pv.get("$rm")~="REGISTER" then return 1; end
	if KSR.isflagset(FLT_NATS) then
		KSR.setbflag(FLB_NATB);
		-- do SIP NAT pinging
		KSR.setbflag(FLB_NATSIPPING);
	end
	local expire_contact = headers.get("$sel(contact.expires)")
    	local expire_header = headers.get("$hdr(Expires)")
    	local rg_status = "rg"
    	if expire_contact == "0" or expire_header == "0" then
                rg_status = "urg"
        end
	if KSR.registrar.save("location", 4)<0 then
		KSR.sl.sl_reply_error();
	end
	ksr_route_register_callback(rg_status)
	KSR.x.exit();
end
--[[--------------------------------------------------------------------------
   Name: ksr_route_cancel_process()
   Desc: -- CANCEL Processing
------------------------------------------------------------------------------]]

function ksr_route_cancel_process(request_method)
    if request_method == "CANCEL" then
        logger.log("info", "Cancel Request Received");
        if core.is_transaction_exist() then
            ksr_route_relay(request_method);
        end
        core.exit()
    end
    return 1;
end

--[[--------------------------------------------------------------------------
   Name: ksr_route_options_process()
   Desc: -- OPTIONS Processing sending keepalive 200
------------------------------------------------------------------------------]]

function ksr_route_options_process(request_method)
    if not (core.is_dialog_request()) then
    	if request_method == "OPTIONS" then
        	logger.log("dbg", "Sending Keepalive 200");
        	core.sl_send_reply(200, "Keepalive");
        	core.exit()
    	end
    end
    return 1;
end

--[[--------------------------------------------------------------------------
   Name: ksr_route_request_process()
   Desc: -- this route is responsible for multiple things:
   1. If request is not INVITE then it will reject the request and send 501
   -- Need to Add code for the trunk regular expression check
------------------------------------------------------------------------------]]

function ksr_route_request_process(request_method)
    headers.remove_header("Route");
    if request_method == "INVITE" then
	core.set_flag(FLT_DIALOG);
	core.dialog_manage()
        logger.log("info", "invite request received, adding record route")
        headers.add_record_route();
	KSR.textopsx.exclude_hf_value("Supported", "timer")
	local source_ip = tostring(headers.get("$si"))
	headers.sets("$avp(src_ip)", tostring(source_ip))
	--KSR.nathelper.fix_nated_sdp_ip(3,"3.220.192.201")
        local sbc_dispatch_set = config.sbc_dispatch_set
        local sbc_default_set = config.sbc_default_set
        local sbc_routing_policy = config.routing_policy
        if dispatcher(sbc_dispatch_set, sbc_default_set, sbc_routing_policy) < 0 then
            logger.log("err", "destination not found in dispatcher, sending 404")
            core.sl_send_reply(404, "No Destination");
            core.exit()
        else
            ksr_route_relay(request_method);
        end
    else
        logger.log("err", "method not allowed sending 501");
        core.sl_send_reply(501, "Method is not implemented");
    end
    core.exit()
end


--[[--------------------------------------------------------------------------
   Name: ksr_route_retrans_process()
   Desc: -- Retransmission Process
------------------------------------------------------------------------------]]

function ksr_route_retrans_process()
    -- handle retransmissions
    if (core.is_retransmission()) then
        logger.log("info", "Retransmission Request Received");
        -- for non-ack and cancel used to send resends the last reply
        -- for that transaction
        core.check_for_active_transaction()
        core.exit()
    end
    if core.check_for_active_transaction() == 0 then
        core.exit()
    end
end

--[[--------------------------------------------------------------------------
   Name: ksr_route_withindlg()
   Desc: -- Handle requests within SIP dialogs
------------------------------------------------------------------------------]]

function ksr_route_withindlg(request_method)
    if not (core.is_dialog_request()) then
        return 1;
    end
    local request_user = headers.get("$tU");
    headers.sets("$rU",request_user);
    --KSR.nathelper.fix_nated_sdp_ip(3,"3.220.192.201")
    logger.log("info", "In-Dialog Request Received");
    -- take the path determined by record-routing
    local source_ip = headers.get("$si")
    if core.loose_route() then
        logger.log("info", "In-Dialog Request Received - loose_route");
   	ksr_route_dlguri();
        if request_method == "ACK" then
            ksr_route_natmanage();
	end
        ksr_route_relay(request_method);
        core.exit()
    end
    logger.log("info", "In-Dialog Request Received - not loose_route")
    if request_method == "ACK" then
            -- no loose-route, but stateful ACK;
            -- must be an ACK after a 487
            -- or e.g. 404 from upstream server
            logger.log("info", "In-Dialog Request Received - not loose_route with transaction - Relaying")
            ksr_route_relay(request_method);
            core.exit()
    end
    logger.log("err", "received invalid SIP packet sending 404");
    core.sl_send_reply(404, "Not here");
    core.exit()
end

--[[--------------------------------------------------------------------------
   Name: ksr_route_dlguri()
   Desc: -- URI update for dialog requests
------------------------------------------------------------------------------]]

function ksr_route_dlguri()
    if not core.is_dest_uri_set() then
        nathandling.du_set_from_alias()
    end
    return 1;
end

--[[--------------------------------------------------------------------------
   Name: ksr_route_relay()
   Desc: adding the reply_route,failure_route,branch_route
         to request. relay the request.
------------------------------------------------------------------------------]]

function ksr_route_relay(req_method)
    -- enable additional event routes for forwarded requests
    -- - serial forking, RTP relaying handling, a.s.o.
    local request_uri = headers.get("$ru") or ""
    local dest_uri = headers.get("$du") or ""
    local proto = headers.get("$pr")

    logger.log("info", "relaying the message with Request-Uri - " .. request_uri
            .. " Destination-Uri - " .. dest_uri);
    if req_method == "BYE" then
        if not (core.is_trans_target_set("branch_route")) then
            core.set_branch_route("ksr_branch_manage");
        end
    elseif req_method == "INVITE" or req_method == "UPDATE" then
        if not (core.is_trans_target_set("branch_route")) then
            core.set_branch_route("ksr_branch_manage");
        end
        if not (core.is_trans_target_set("onreply_route")) then
            core.set_reply_route("ksr_onreply_manage");
        end
        if not (core.is_trans_target_set("failure_route")) and (req_method == "INVITE") then
            core.set_failure_route("ksr_failure_manage");
        end
    end
    if not (core.relay()) then
        logger.log("err", "sip meesage not relayed");
        core.sl_reply_error();
    end
    core.exit()
end

--[[--------------------------------------------------------------------------
   Name: ksr_route_natmanage()
   Desc: caller NAT detection and add contact alias
------------------------------------------------------------------------------]]

function ksr_route_natdetect()
    nathandling.add_rport()
    if nathandling.is_behind_nat() then
        if core.is_first_hop() then
            nathandling.add_contact_alias();
        end
        core.set_flag(FLT_NATS);
    end
    return 1;
end

--[[--------------------------------------------------------------------------
   Name: ksr_route_natmanage()
   Desc: managing the sip-response and sip-request behind the
         nat
------------------------------------------------------------------------------]]
function ksr_route_natmanage()
    if core.is_sip_request() > 0 then
        if core.is_dialog_request() then
            if headers.check_route_params("nat=yes") > 0 then
                core.set_branch_flag(FLB_NATB);
            end
        end
    end
    if core.is_sip_request() > 0 then
        if not core.is_dialog_request() then
            if core.is_top_branch_route() then
		logger.log("info","not adding nat")
                --headers.add_rr_params(";nat=yes")
            end
        end
    elseif core.is_sip_reply() > 0 then
            nathandling.add_contact_alias();
	    logger.log("info", "We are adding contact alias here")
    end
    return 1;
end

--[[--------------------------------------------------------------------------
   Name: ksr_branch_manage()
   Desc: managing outgoing branch
------------------------------------------------------------------------------]]

function ksr_branch_manage()
    logger.log("dbg", "new branch [" .. headers.get("$T_branch_idx")
            .. "] to " .. headers.get("$ru"));
    ksr_route_natmanage();
    return 1;
end

--[[--------------------------------------------------------------------------
   Name: ksr_onreply_manage()
   Desc: managing incoming response for the request
------------------------------------------------------------------------------]]

function ksr_onreply_manage()
    local response_code = headers.get("$rs")
    logger.log("info", "incoming reply with response code " .. response_code);
    if response_code > 100 and response_code < 299 then
	local src_ip = headers.get("$dlg_var(src_ip)") or "false";
	if src_ip == "false" then
		src_ip = headers.get("$avp(src_ip)") or "false"
		headers.sets("$dlg_var(src_ip)", src_ip)
		KSR.nathelper.add_contact_alias()
	end
        ksr_route_natmanage();
    end
    return 1;
end

--[[--------------------------------------------------------------------------
   Name: ksr_failure_manage()
   Desc: managing the failure response 3xx,4xx,5xx
------------------------------------------------------------------------------]]

function ksr_failure_manage()
    local response_code = headers.get("$T(reply_code)")
    logger.log("err", "failure route: incoming reply received - " .. response_code);
    local request_method = headers.get("$rm") or "INVITE";
    ksr_route_natmanage();
    headers.remove_header("Server");
    if core.is_transacation_canceled() then
        logger.log("info", "call get canceled, exit from the script")
        core.exit()
    elseif core.is_status("408") then
        core.disable_internal_reply()
        logger.log("err", "reply generated by loadbalancer server, sending 503")
        core.send_reply(503, "Service Unavailable")
        core.exit()
    elseif core.is_status("503|4[0-9][0-9]") then
        core.disable_internal_reply()
        core.exit()
    elseif core.is_status("50[0-9]") or core.is_branch_timeout() or not (core.is_branch_replied()) then
        logger.log("info", "trying for next gateway")
        if (core.get_next_destination()) then
            local destination_uri = headers.get("$du") or ""
            logger.log("info", "next destination is " .. destination_uri);
            ksr_route_relay(request_method)
            core.exit()
        end
        core.disable_internal_reply()
        logger.log("err", "no more destination found in dispatcher, sending 503")
        core.send_reply(503, "Service Unavailable");
        core.exit()
    else
        core.disable_internal_reply()
        logger.log("err", "no more destination found in dispatcher, sending 503")
        core.send_reply(503, "Service Unavailable");
        core.exit()
    end
end

--[[--------------------------------------------------------------------------
   Name: dispatcher(dispatch_domain, routing_policy)
   Desc: get the dispatch domain from the dispatcher list based on policy
------------------------------------------------------------------------------]]

function dispatcher(dispatch_domain, default_domain, routing_policy)
    -- Dispatching call to plivo outproxy
    if core.set_destination_uri(dispatch_domain, routing_policy) then
        logger.log("info", "After Dispatcher-Lookup: Request-uri - "
                .. headers.get("$ru"))
        return 1
    elseif (default_domain) and (default_domain ~= dispatch_domain)
            and (core.set_destination_uri(default_domain, routing_policy)) then
        logger.log("err", "DISPATCH no server available for dispatch-domain, "
                .. dispatch_domain .. " Looking for default-route - "
                .. default_domain)
        logger.log("info", "After Dispatcher-Lookup to Default-Route: Request-uri - "
                .. headers.get("$ru"))
        return 1
    else
        logger.log("err", "DISPATCH no server available, sending SIP 503 Service Unavailable")
        core.sl_send_reply(503, "Service Unavailable");
        core.exit()
        return -1
    end
end
