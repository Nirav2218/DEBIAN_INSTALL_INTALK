# agami-sip-registrar

### SHM_SIZE=$((TOTAL_MEM / 2)) 8192 (-m)

### PKG_SIZE = $((TOTAL_MEM / 4)) 3072 (-M)


### Multidomain support from db 
Schema changes required
--
-- Table structure for table `domain`
--

CREATE TABLE `domain` (
  `id` int UNSIGNED NOT NULL,
  `domain` varchar(64) NOT NULL,
  `did` varchar(64) DEFAULT NULL,
  `last_modified` datetime NOT NULL DEFAULT '2000-01-01 00:00:01'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;



-- --------------------------------------------------------

--
-- Table structure for table `domain_attrs`
--

CREATE TABLE `domain_attrs` (
  `id` int UNSIGNED NOT NULL,
  `did` varchar(64) NOT NULL,
  `name` varchar(32) NOT NULL,
  `type` int UNSIGNED NOT NULL,
  `value` varchar(255) NOT NULL,
  `last_modified` datetime NOT NULL DEFAULT '2000-01-01 00:00:01'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `domain`
--
ALTER TABLE `domain`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `domain_idx` (`domain`);

--
-- Indexes for table `domain_attrs`
--
ALTER TABLE `domain_attrs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `domain_attrs_idx` (`did`,`name`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `domain`
--
ALTER TABLE `domain`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `domain_attrs`
--
ALTER TABLE `domain_attrs`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT;
COMMIT;


After adding domain to database please use below command to dynamically reload
kamcmd -s tcp:private_ip:2046 domain.reload
kamcmd -s tcp:private_ip:2046 domain.dump


