-- Global Config

local globals = {}
globals.reject_user_agent_list = {
    'sipcli', 'sipvicious', 'sip-scan', 'sipsak', 'sundayddr', 'friendly-scanner',
    'iWar', 'CSipSimple', 'SIVuS', 'Gulp', 'sipv', 'smap', 'friendly-request', 'VaxIPUserAgent', 'VaxSIPUserAgent',
    'siparmyknife', 'Test Agent'
} -- Reject UserAgent List
globals.max_forward = 10 --MAX-FORWARD
globals.routing_policy = 4
globals.sbc_dispatch_set = 1
globals.sbc_default_set = 1
globals.sip_invalid_destination_code = 400
globals.sip_invalid_destination_code_q850 = 3
globals.sip_invalid_destination_phrase = "Bad Request"
globals.callback_url = "https://webhook.site/ed57714f-bf6d-402a-ae97-f036e61262e8" -- POST method will be used
return globals
