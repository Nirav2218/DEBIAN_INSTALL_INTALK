local core = {}

--[[------------------------------------------------------------------------
   Name: exit()
   Desc: stop the execution of the SIP routing script.
----------------------------------------------------------------------------]]

function core.exit()
    KSR.x.exit()
end

--[[------------------------------------------------------------------------
   Name: set_flag(flag)
   Desc: This function sets the value of the flag given as parameter to 1
   (true).The value of the parameter must be an integer between 0 and 31.
----------------------------------------------------------------------------]]

function core.set_flag(flag)
    KSR.setflag(flag)
end

function core.dialog_manage()
    KSR.dialog.dlg_manage()
end
--[[------------------------------------------------------------------------
   Name: set_branch_flag(flag)
   Desc: Set the branch flag.
----------------------------------------------------------------------------]]

function core.set_branch_flag(flag)
    KSR.setbflag(flag)
end

--[[------------------------------------------------------------------------
   Name: is_flag_set(flag)
   Desc: Return true if given flag value is 1 or true
----------------------------------------------------------------------------]]

function core.is_flag_set(flag)
    return KSR.isflagset(flag)
end

--[[------------------------------------------------------------------------
   Name: is_branch_flag_set(flag)
   Desc: Return true if given branch flag value is 1 or true
----------------------------------------------------------------------------]]

function core.is_branch_flag_set(flag)
    return KSR.isbflagset(flag)
end


--[[------------------------------------------------------------------------
   Name: is_transaction_exist()
   Desc: used to quickly check if a message belongs or is related to a
   transaction.

   For a SIP Reply: it returns 1 if the reply belongs to an existing
   transaction and -1 otherwise.

   For a CANCEL: returns 1 if a corresponding INVITE transaction exists
   for the CANCEL and -1 otherwise.

   For ACKs to negative replies or for ACKs to local transactions: it will
   terminate the script if the ACK belongs to a transaction or return
   -1 if not.
   (it would make very little sense to process an ACK to a negative reply
   for an existing transaction in some other way then to simply pass it to tm)

   For end-to-end ACKs: (ACKs to 2xx responses for forwarded INVITE
   transactions) it will return 1 if the corresponding INVITE transaction is
   found and still active and -1 if not.

   For other requests (non ACKs and non CANCELs), in case of a retransmission
   matching a transaction, it resends the last reply for that transaction
   and terminates the config execution. Otherwise, it returns -1.
----------------------------------------------------------------------------]]

function core.is_transaction_exist()
    return KSR.tm.t_check_trans() > 0
end

--[[------------------------------------------------------------------------
   Name: is_local_message(sip_uri)
   Desc: Return true if the sip_uri matches the 'myself' condition
   (i.e., is a local IP or domain).
----------------------------------------------------------------------------]]

function core.is_local_message(sip_uri)
    return KSR.is_myself(sip_uri)
end

--[[------------------------------------------------------------------------
   Name: is_var_null(kamvar)
   Desc: Return true if pseudo-variable kamvar is $null, else False.
----------------------------------------------------------------------------]]

function core.is_var_null(kamvar)
    return KSR.pv.is_null(kamvar)
end

--[[------------------------------------------------------------------------
   Name: is_retransmission()
   Desc: The function returns true if the request is handled
   by another process
----------------------------------------------------------------------------]]

function core.is_retransmission()
    return KSR.tmx.t_precheck_trans() > 0
end

--[[------------------------------------------------------------------------
   Name: is_transacation_canceled()
   Desc: returns: 1 if the transaction was canceled, -1 if not
----------------------------------------------------------------------------]]

function core.is_transacation_canceled()
    return KSR.tm.t_is_canceled() > 0
end

--[[------------------------------------------------------------------------
   Name: is_sip_reply()
   Desc: return 1 if the SIP message type is reply
----------------------------------------------------------------------------]]

function core.is_sip_reply()
    return KSR.siputils.is_reply()
end

--[[------------------------------------------------------------------------
   Name: is_sip_request()
   Desc: return 1 if the SIP message type is request
----------------------------------------------------------------------------]]

function core.is_sip_request()
    return KSR.siputils.is_request()
end

--[[------------------------------------------------------------------------
   Name: is_dialog_request()
   Desc: return true if the SIP message is in dialog request else false
----------------------------------------------------------------------------]]

function core.is_dialog_request()
    return KSR.siputils.has_totag() > 0
end

--[[------------------------------------------------------------------------
   Name: is_top_branch_route()
   Desc: Returns true if the top-executed route block is branch_route.
----------------------------------------------------------------------------]]

function core.is_top_branch_route()
    return KSR.tmx.t_is_branch_route() > 0
end

--[[------------------------------------------------------------------------
   Name: is_first_hop()
   Desc: The function returns true if the proxy is first hop after
   the original sender.
----------------------------------------------------------------------------]]

function core.is_first_hop()
    return KSR.siputils.is_first_hop() > 0
end

--[[------------------------------------------------------------------------
   Name: loose_route()
   Desc: The function performs routing of SIP requests which contain a route set
----------------------------------------------------------------------------]]
function core.loose_route()
    return KSR.rr.loose_route() > 0
end

--[[------------------------------------------------------------------------
   Name: is_dest_uri_set()
   Desc: Returns true if the destination uri is set
----------------------------------------------------------------------------]]
function core.is_dest_uri_set()
    return KSR.isdsturiset()
end

--[[------------------------------------------------------------------------
   Name: is_trans_target_set()
   Desc: Return true if the attribute specified by 'target' is set for transaction.
----------------------------------------------------------------------------]]
function core.is_trans_target_set(target)
    return KSR.tm.t_is_set(target) > 0
end

--[[------------------------------------------------------------------------
   Name: set_branch_route()
   Desc: Sets the branch routing block, to which control is passed after forking
   (when a new branch is created)
----------------------------------------------------------------------------]]
function core.set_branch_route(target_route)
    KSR.tm.t_on_branch(target_route);
end

--[[------------------------------------------------------------------------
   Name: set_reply_route()
   Desc: Sets the reply routing block, to which control is passed when a reply
   for the current transaction is received
----------------------------------------------------------------------------]]
function core.set_reply_route(target_route)
    KSR.tm.t_on_reply(target_route);
end

--[[------------------------------------------------------------------------
   Name: set_failure_route()
   Desc: Sets failure routing block, to which control is passed after a
   transaction completed with a negative result but before sending a final reply
----------------------------------------------------------------------------]]
function core.set_failure_route(target_route)
    KSR.tm.t_on_failure(target_route);
end

--[[------------------------------------------------------------------------
   Name: relay()
   Desc: Relay a message statefully either to the destination indicated in
   the current URI (if called without any parameters) or to the specified host
   and port
----------------------------------------------------------------------------]]
function core.relay()
    return KSR.tm.t_relay() > 0
end

--[[------------------------------------------------------------------------
   Name: is_from_ds_list()
   Desc: This function returns true, if there is a match of source address or
   uri with an address in the given group of the dispatcher-list; otherwise false.
----------------------------------------------------------------------------]]
function core.is_from_ds_list(list_id)
    return KSR.dispatcher.ds_is_from_list(list_id) > 0
end

--[[---------------------------------------------------------------------------
   Name: get_next_destination()
   Desc: Takes the next destination address from the AVPs with id 'dst_avp_id'
   and sets the dst_uri.
------------------------------------------------------------------------------]]

function core.get_next_destination()
    return KSR.dispatcher.ds_next_domain() > 0
end

--[[------------------------------------------------------------------------
   Name: ip_is_in_subnet()
   Desc: Returns true if IP is in subnet
----------------------------------------------------------------------------]]
function core.ip_is_in_subnet(ipv4, cidr)
    return KSR.ipops.ip_is_in_subnet(ipv4, cidr) > 0
end


--[[------------------------------------------------------------------------
   Name: check_maxfwd(max_limit)
   Desc: If no Max-Forward header is present in the received request,
   a header will be added having the original value equal with “max_value”.
   If a Max-Forward header is already present, its value will be decremented
   (if not 0). The parameter can be a variable.

Return codes:

2 (true) - header was not found and a new header was successfully added.

1 (true) - header was found and its value was successfully decremented
(had a non-0 value).

-1 (false) - the header was found and its value is 0 (cannot be decremented).

-2 (false) - error during processing.
----------------------------------------------------------------------------]]
function core.check_maxfwd(max_limit)
    return KSR.maxfwd.process_maxfwd(max_limit) > 0
end

--[[------------------------------------------------------------------------
   Name: sanity()
   Desc: This function makes a row of sanity checks over the given SIP request
----------------------------------------------------------------------------]]
function core.sanity()
    return KSR.sanity.sanity_check(1511, 7) > 0
end

--[[------------------------------------------------------------------------
   Name: sl_send_reply()
   Desc: For the current request, a reply is sent back having the given code
   and text reason. The reply is sent stateful or stateless, depending of the
   TM module: if a transaction exists for the current request, then the reply
   is sent statefully, otherwise stateless.
----------------------------------------------------------------------------]]
function core.sl_send_reply(sip_response_code, message)
    KSR.sl.sl_send_reply(sip_response_code, message);
end

function core.send_reply(sip_response_code, message)
    KSR.sl.send_reply(sip_response_code, message);
end

--[[------------------------------------------------------------------------
   Name: sl_reply_error()
   Desc: Sends back an error reply describing the nature of the last internal
   error
----------------------------------------------------------------------------]]
function core.sl_reply_error()
    KSR.sl.sl_reply_error();
end

--[[------------------------------------------------------------------------
   Name: set_destination_uri()
   Desc: The method selects a destination from addresses set and rewrites the
   host and port from R-URI
----------------------------------------------------------------------------]]
function core.set_destination_uri(dispatch_domain, routing_policy)
    return KSR.dispatcher.ds_select_domain(dispatch_domain, routing_policy) > 0
end

--[[------------------------------------------------------------------------
   Name: create_transaction()
   Desc: Creates a new transaction, returns a negative value on error
----------------------------------------------------------------------------]]
function core.create_transaction()
    return KSR.tm.t_newtran() > 0
end

--[[------------------------------------------------------------------------
   Name: delete_transaction()
   Desc: Remove transaction from memory (it will be first put on a wait timer
   to absorb delayed messages).
----------------------------------------------------------------------------]]
function core.delete_transaction()
    return KSR.tm.t_release() > 0
end

--[[------------------------------------------------------------------------
   Name: http_async_get_request()
   Desc: Sends HTTP(S) request asynchronously to the URL given in “url”
   parameter, which is a string that may contain pseudo variables.
----------------------------------------------------------------------------]]
function core.http_async_get_request(url, callback)
    return KSR.http_async_client.query(url, callback)
end

--[[------------------------------------------------------------------------
   Name: resume_transaction()
   Desc: Continue the execution of the transaction identified by tindex and
   tlabel with the actions defined in route
----------------------------------------------------------------------------]]
function core.resume_transaction(t_index, t_label, callback_route)
    return KSR.tmx.t_continue(t_index, t_label, callback_route)
end

--[[------------------------------------------------------------------------
   Name: evapi_async_request()
   Desc: Relay the event data given as parameter to connected applications
----------------------------------------------------------------------------]]
function core.evapi_async_request(evapi_request_json)
    KSR.evapi.async_relay(evapi_request_json)
end

--[[------------------------------------------------------------------------
   Name: check_for_active_transaction()
   Desc: Method used to quickly check if a message belongs or is related to a
   transaction.

   Return code depends on type of message:
   1. For a SIP Reply it returns true if the reply belongs to an existing
   transaction and false otherwise.

   2. For a CANCEL it behaves exactly as t_lookup_cancel(): returns true if a
   corresponding INVITE transaction exists for the CANCEL and false otherwise.

   3. For ACKs to negative replies or for ACKs to local transactions it will
   terminate the script if the ACK belongs to a transaction or return false if not.

   4. For end-to-end ACKs (ACKs to 2xx responses for forwarded INVITE transactions)
   it will return true if the corresponding INVITE transaction is found and still
   active and false if not.
----------------------------------------------------------------------------]]
function core.check_for_active_transaction()
    return KSR.tm.t_check_trans()
end

function core.is_status(status)
    return KSR.tm.t_check_status(status) > 0
end

function core.is_branch_replied()
    return KSR.tm.t_branch_replied() > 0
end

function core.is_branch_timeout()
    return KSR.tm.t_branch_timeout() > 0
end

function core.disable_internal_reply()
    return KSR.tm.t_set_disable_internal_reply(1);
end
--[[------------------------------------------------------------------------
   Name: remove_header_value()
   Desc: remove the header's value from a header
   Examples :   remove_hf_value("foo")  # remove foo[1]
                remove_hf_value("foo[*]")  # remove all foo's headers
                remove_hf_value("foo[-1]") # last foo
                remove_hf_value("foo.bar")  # delete parameter
                remove_hf_value("foo[*].bar") # for each foo delete bar parameters
----------------------------------------------------------------------------]]
function core.remove_header_value(header_val)
    return KSR.textopsx.remove_hf_value(header_val)
end

return core
