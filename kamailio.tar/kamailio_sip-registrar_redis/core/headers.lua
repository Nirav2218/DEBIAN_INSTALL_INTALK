-- Functions working with headers
local headers = {}

-- Reason Header Variable
headers.reason_string = "Q.850; cause=%s; text=\"InternalDiagCode: %s, InternalErrorPhrase: %s\""
-- Reason Header's Text
headers.reason_text = {}
headers.reason_text[3] = { "InvalidDestination", "Destination number with malformed syntax" }

--[[------------------------------------------------------------------------
   Name: get(header)
   Desc: get the value of header or kamailio variable
   and return the value.
----------------------------------------------------------------------------]]

function headers.get(header)
    return KSR.pv.get(header)
end

--[[------------------------------------------------------------------------
   Name: sets(header, value)
   Desc: set the int value to header or kamailio variable.
----------------------------------------------------------------------------]]

function headers.seti(header, value)
    KSR.pv.seti(header, value)
end

--[[------------------------------------------------------------------------
   Name: sets(header, value)
   Desc: set the string value to header or kamailio variable.
----------------------------------------------------------------------------]]

function headers.sets(header, value)
    KSR.pv.sets(header, value)
end

--[[------------------------------------------------------------------------
   Name: append_header(header, value)
   Desc: add new header with the value to the request
----------------------------------------------------------------------------]]

function headers.append_header(header, value)
    if header == nil then return false end
    return KSR.hdr.append(header .. ": " .. value .. "\r\n")
end

--[[------------------------------------------------------------------------
   Name: remove_header(header)
   Desc: remove the header from the request
----------------------------------------------------------------------------]]

function headers.remove_header(header)
    if header == nil then
        return false
    end
    return KSR.hdr.remove(header)
end

--[[------------------------------------------------------------------------
   Name: remove_header_re(header)
   Desc: remove the header from the request which match pattern
----------------------------------------------------------------------------]]
function headers.remove_header_re(header)
    if header == nil then
        return false
    end
    return KSR.textops.remove_hf_re(header)
end

--[[------------------------------------------------------------------------
   Name: add_record_route()
   Desc: add the record-route header to the request
----------------------------------------------------------------------------]]

function headers.add_record_route()
    return KSR.rr.record_route()
end

--[[------------------------------------------------------------------------
   Name: add_rr_params()
   Desc: add the param to route header
----------------------------------------------------------------------------]]

function headers.add_rr_params(str)
    return KSR.rr.add_rr_param(str);
end

--[[------------------------------------------------------------------------
   Name: check_route_params()
   Desc: check the route header params
----------------------------------------------------------------------------]]

function headers.check_route_params(str)
    return KSR.rr.check_route_param(str)
end

--[[------------------------------------------------------------------------
   Name: is_present(header)
   Desc: check whether header is present or not
----------------------------------------------------------------------------]]
function headers.is_present(header)
    if header == nil then return false end
    return KSR.hdr.is_present(header) > 0
end

--[[------------------------------------------------------------------------
   Name: myself()
   Desc: check whether messge coming from myself
----------------------------------------------------------------------------]]
function headers.myself()
    return KSR.is_myself(KSR.pv.get("$si"))
end

--[[------------------------------------------------------------------------
   Name: is_ip_banned()
   Desc: tells whether IP banned or not
----------------------------------------------------------------------------]]
function headers.is_ip_banned()
    return not KSR.pv.is_null("$sht(ipban=>$si)")
end

--[[------------------------------------------------------------------------
   Name: pike_above_limit()
   Desc: check whether threshold crossed or not
----------------------------------------------------------------------------]]
function headers.pike_above_limit()
    return KSR.pike.pike_check_req() < 0
end

--[[------------------------------------------------------------------------
   Name: ban_ip()
   Desc: Add banned IP to hash table
----------------------------------------------------------------------------]]
function headers.ban_ip()
    KSR.pv.seti("$sht(ipban=>$si)", 1)
end

--[[------------------------------------------------------------------------
   Name: append_header_to_reply(header, value)
   Desc: add a header to the SIP response to be generated by Kamailio for the current SIP request
----------------------------------------------------------------------------]]

function headers.append_header_to_reply(header, value)
    if header == nil then return false end
    return KSR.hdr.append_to_reply(header .. ": " .. value .. "\r\n");
end

--[[------------------------------------------------------------------------
   Name: append_reason_header(header, value)
   Desc: add a reason header based on cause code and manage reason text by own
----------------------------------------------------------------------------]]

function headers.append_reason_header(cause_code)
    if cause_code == nil or headers.reason_text[cause_code] == nil then return false end
    reason_value = string.format(headers.reason_string, cause_code, headers.reason_text[cause_code][1], headers.reason_text[cause_code][2])
    return headers.append_header_to_reply("X-Plivo-Reason", reason_value);
end

return headers
