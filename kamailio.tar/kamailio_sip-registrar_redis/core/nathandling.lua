local nathandling = {}

--[[------------------------------------------------------------------------
   Name: is_behind_nat()
   Desc: check whether client is behind nat if so then true else false
----------------------------------------------------------------------------]]

function nathandling.is_behind_nat()
    return KSR.nathelper.nat_uac_test(19) > 0
end

--[[------------------------------------------------------------------------
   Name: add_rport()
   Desc: force_rport() adds the rport (received-port) parameter to the
   first Via header of the received message.
----------------------------------------------------------------------------]]

function nathandling.add_rport()
    return KSR.force_rport()
end

--[[------------------------------------------------------------------------
   Name: is_transacation_canceled()
   Desc: Adds ;alias=ip~port~proto param to contact uri containing received
   ip,port, and transport proto if contact uri ip and port do not match
   received ip and port.
----------------------------------------------------------------------------]]

function nathandling.add_contact_alias()
    return KSR.nathelper.set_contact_alias();
end

function nathandling.du_set_from_alias()
    return KSR.nathelper.handle_ruri_alias();
end

return nathandling