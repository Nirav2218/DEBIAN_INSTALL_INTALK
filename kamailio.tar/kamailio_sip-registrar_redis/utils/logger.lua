-- Zen-Trunk : Logger

-- ----------------- Import Lua Modules ------------------------------------
package.path = package.path .. ";/etc/kamailio/?.lua" ..
        ";/etc/kamailio/core/?.lua" .. ";../../../zt-loadbalancer/src/?.lua" ..
        ";../../../zt-loadbalancer/src/core/?.lua"
included_modules = {
    "headers"
}
for _, module in pairs(included_modules) do
    package.loaded[module] = nil
end
headers = require "headers"
local logger = {}

--[[------------------------------------------------------------------------
   Name: log( level, message )
   Desc: log to stream for given log level
----------------------------------------------------------------------------]]

function logger.log(level, message)
    local call_id = headers.get("$ci") or ""
    local src_ip = headers.get("$si") or ""
    local src_port = headers.get("$sp") or ""
    local proto = headers.get("$pr") or ""
    local method = headers.get("$rm") or ""
    local trunk_name = headers.get("$rd") or ""
    local log_header = "" .. call_id .. "|" .. proto .. ":" .. src_ip .. ":" .. src_port
            .. "|" .. method .. "|" .. trunk_name .. "|"
    KSR.log(level, log_header .. message .. "\n")
end

return logger
