-- utility function

json = require 'cjson'
util = require 'cjson.util'

local kamutils = {}

--[[---------------------------------------------------------
   Name: pattern_check(str_check, list)
   Desc: check str_check into list, if found then return true
   and false.
-----------------------------------------------------------]]

function kamutils.pattern_check(str_check, list)
    if (not (kamutils.is_empty(str_check) or kamutils.is_empty(list))) then
        for i, element in ipairs(list) do
            local escape_element = kamutils.escape_char(element);
            if string.find(str_check, escape_element) then
                return true;
            end
        end
    end
    return false;
end

--[[---------------------------------------------------------
   Name: escape_char(str_check)
   Desc: escape the special character in the string
   and return the escaped string.
-----------------------------------------------------------]]

function kamutils.escape_char(str_check)
    if (not kamutils.is_empty(str_check)) then
        escape_str = string.gsub(str_check, "%p", "%%%1")
        return escape_str;
    end
    return str_check;
end

--[[---------------------------------------------------------
   Name: match_regex(str_check, regex)
   Desc: checking whether the given string is match with
   regex or not if matched then return true else false
-----------------------------------------------------------]]

function kamutils.match_regex(str_check, regex)
    if (not (kamutils.is_empty(str_check) or kamutils.is_empty(regex)))
            and string.find(str_check, regex) then
        return true;
    else
        return false;
    end
end

--[[---------------------------------------------------------
   Name: is_empty(str_check)
   Desc: checking whether the given string is nil or empty
   and return true if nil or empty
-----------------------------------------------------------]]

function kamutils.is_empty(str_check)
    return str_check == nil or str_check == ''
end

--[[---------------------------------------------------------
   Name: load_table(json_file)
   Desc: loading the given json file into table and
   return the table
-----------------------------------------------------------]]

function kamutils.load_table(json_file)
    if kamutils.file_exists(json_file) then
        return json.decode(util.file_load(json_file))
    end
    return false
end

--[[---------------------------------------------------------
   Name: file_exists(file_name)
   Desc: checking whether given file exist or not
-----------------------------------------------------------]]

function kamutils.file_exists(file_name)
    local f = io.open(file_name, "r")
    if f ~= nil then io.close(f) return true else return false end
end

--[[---------------------------------------------------------
   Name: file_write(file_name, data)
   Desc: writing the given data to given file
-----------------------------------------------------------]]
function kamutils.file_write(file_name, data)
    file = io.open(file_name, "w")
    if file then
        file:write(data)
        file:close()
        return true
    end
    return false
end

--[[---------------------------------------------------------
   Name: stripchars(str, chrs)
   Desc: remove given characters from the string
-----------------------------------------------------------]]

function kamutils.stripchars(str, chrs)
  local s = string.gsub(str,"["..chrs:gsub("%W","%%%1").."]", '')
  return s
end

--[[---------------------------------------------------------
   Name: split(s, delimiter)
   Desc: split the string wrt given delimiter and return them
   as a table
-----------------------------------------------------------]]
function kamutils.split(s, delimiter)
    local result = {};
    for match in (s .. delimiter):gmatch("(.-)" .. delimiter) do
        table.insert(result, match);
    end
    return result;
end

--[[---------------------------------------------------------
   Name: get_index_by_value(list, value)
   Desc: get the key index wrt the given value from a table
-----------------------------------------------------------]]
function kamutils.get_index_by_value(list, value)
    local index = {}
    for k, v in pairs(list) do
        index[v] = k
    end
    return index[value]
end

return kamutils
