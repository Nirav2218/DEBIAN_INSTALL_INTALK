#! /bin/bash
echo "Hello from $1"